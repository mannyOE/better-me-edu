$(window).load(function(){
		$('.blueberry').blueberry();
	});
$('.handle').on('click',function(){
		$('nav ul').toggleClass('showing');
	})