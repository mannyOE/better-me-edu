<header>
		<div id="top-info">
			<section>
				<h1 style="font-size: 3em;" id="name" class="fonts"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme Consultants</h1><h1 id="name2" class="fonts" style="font-size: 3em;"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme</h1>
			</section>
			
		</div>
	<div class="handle fonts">Menu<span class="icon icon-align-justify pull-right"></span>
</div>
<nav id="nal-ul">
	<ul id="nav" class="fonts">
	<?php if(!isset($_SESSION['is_logged_in'])){?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Login</li></a>
	<?php }else{?>
		<a href="<?php echo site_url()?>better/logout"><li class="pull-right">Logout</li></a>
	<?php }?>
		<a href="<?php echo site_url()?>better/contact_page"><li class="pull-right">Contact</li></a>
		<a href="<?php echo site_url()?>better/gallery_page"><li class="pull-right">Gallery</li></a>
		<a href="<?php echo site_url()?>better/admissions_page"><li class="pull-right active-link">Admissions</li></a>
		<a href="<?php echo site_url()?>better/about_page"><li class="pull-right ">About</li></a>
		<a href="<?php echo site_url()?>"><li class="pull-right">Home</li></a>

		
	</ul>
</nav>
</header>

<section>
<div style="text-align: center;" ><h1>Passport Photo Upload</h1>
	<div class="row suby">
		<div class="col-lg-4">
			
		</div>
		<div class="col-lg-4">
			<div class="row">
				<div class="col-lg-3"></div>
				<div class="col-lg-6">
					<form action="<?php echo site_url();?>/maple_controller/photo_upload"
                    class="dropzone"
                    id="my-awesome-dropzone">
                      <div class="dz-message photo-space" data-dz-message><i class="fa fa-upload btn-lg"></i><span>Drop Photo here to Upload</span></div>
                      <div class="dz-message photo-space-1" data-dz-message><i class="fa fa-upload btn-lg"></i><span>Tap here to Upload</span></div>
                    </form>
				</div>
				<div class="col-lg-3"></div>
			</div>
			<button class="btn-subscribe pull-right">Finish</button>
		</div>
		<div class="col-lg-4 suby subs-form category">
			<h2>Catgory</h2>
			<a href="<?php echo site_url()?>better/FradPOSKBDVECWHVCGVTYFWYUHIUhduewfgeywuuqiefgeyw/name/ahman">PLO</a>
		</div>
	</div>
</section>





<script type="text/javascript">

</script>
<style type="text/css">
	label{
		font-size: 22px;
		font-family: Ubuntu;
		font-weight: bold;
	}
</style>