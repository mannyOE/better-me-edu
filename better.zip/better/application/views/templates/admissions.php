
<header>
		<div id="top-info">
			<section>
				<h1 style="font-size: 3em;" id="name" class="fonts"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme Consultants</h1><h1 id="name2" class="fonts" style="font-size: 3em;"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme</h1>
			</section>
			
		</div>
	<div class="handle fonts">Menu<span class="icon icon-align-justify pull-right"></span>
</div>
<nav id="nal-ul">
	<ul id="nav" class="fonts">
	<?php if(!isset($_SESSION['is_logged_in'])){?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Login</li></a>
	<?php }else{?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Logout</li></a>
	<?php }?>
		<a href="<?php echo site_url()?>better/contact_page"><li class="pull-right">Contact</li></a>
		<a href="<?php echo site_url()?>better/gallery_page"><li class="pull-right">Gallery</li></a>
		<a href="<?php echo site_url()?>better/admissions_page"><li class="pull-right active-link">Admissions</li></a>
		<a href="<?php echo site_url()?>better/about_page"><li class="pull-right ">About</li></a>
		<a href="<?php echo site_url()?>"><li class="pull-right">Home</li></a>

		
	</ul>
</nav>
</header>

<section>
	<div class="row ">
		<div class="col-lg-4 suby" style="padding-left: 50px; padding-top: 70px; text-align: center;">
			Already have an account? <a href="<?php echo site_url()?>better/login_page">Login Here</a>
			<div class="container-fluid">
				<div class="blueberry" style="max-width: 600px;">
					<ul class="slides">
						<a href="<?php echo site_url()?>"><li><img src="<?php echo site_url()?>images/students.jpg"><div class="carousel-caption" style="padding-bottom: 50px;">Happy Children</div></li></a>
						<a href="<?php echo site_url()?>"><li><img src="<?php echo site_url()?>images/kids.jpg"><div class="carousel-caption" style="padding-bottom: 50px;">Happy Children</div></li></a>
						<a href="<?php echo site_url()?>"><li><img src="<?php echo site_url()?>images/hjids.jpg"><div class="carousel-caption" style="padding-bottom: 50px;">Happy Children</div></li></a>
					</ul>
				</div>
			</div>
		</div>
		<div class="col-lg-4">
			<div class="row suby ">
					<form action="<?php echo site_url()?>better/signup" method="post">
					<h2 class="">Signup Here</h2><h5>(All Fields are Compulsory)</h5>
					<span id="error-form"><?php echo $msg;?></span><br><br>
					<label id="fn-adm">First Name</label>
					<input type="text" id="form-input" name="fname" value="<?php echo set_value('fname'); ?>" placeholder="First Name" >
					<span id="error-form"><?php echo form_error('fname'); ?></span>

					<label id="mn-adm">Middle Name</label>
					<input type="text" id="form-input" name="mname" value="<?php echo set_value('mname'); ?>" placeholder="Middle Name">
					<span id="error-form"><?php echo form_error('mname'); ?></span>

					<label id="ln-adm">Last Name</label>
					<input type="text" id="form-input" name="lname" value="<?php echo set_value('lname'); ?>" placeholder="Last Name">
					<span id="error-form"><?php echo form_error('lname'); ?></span>

					<label id="em-adm">Email</label>
					<input id="form-input" type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="Email">
					<span id="error-form"><?php echo form_error('email'); ?></span>

					<label id="ph-adm">Phone</label>
					<input id="form-input" type="text" name="phone" value="<?php echo set_value('phone'); ?>" placeholder="Phone" >
					<span id="error-form"><?php echo form_error('phone'); ?></span>

					<label id="u-adm">Choose Username</label>
					<input id="form-input" type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="Choose Username">
					<span id="error-form"><?php echo form_error('username'); ?></span>

					<label id="p-adm">Choose Password</label>
					<input id="form-input" type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Choose Password" >
					<span id="error-form"><?php echo form_error('password'); ?></span>

					<label id="pc-adm">Password Confirm</label>
					<input id="form-input" type="password" name="confirmPassword" value="<?php echo set_value('confirmPassword'); ?>" placeholder="Password Confirm" >
					<span id="error-form"><?php echo form_error('confirmPassword'); ?></span>

					<button class="btn-subscribe">Signup</button>

					</form>
				
			</div>
		</div>
		<div class="col-lg-4 suby subs-form category">
			<h2>Catgory</h2>
			<a href="<?php echo site_url()?>better/FradPOSKBDVECWHVCGVTYFWYUHIUhduewfgeywuuqiefgeyw/name/ahman">PLO</a>
		</div>
	</div>
</section>





<script type="text/javascript">

</script>
<style type="text/css">
	label{
		font-size: 22px;
		font-family: Ubuntu;
		font-weight: bold;
	}
</style>