
<header>
		<div id="top-info">
			<section>
				<h1 style="font-size: 5em;" id="name" class="fonts"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme Educational Consultants</h1><h1 id="name2" class="fonts" style="font-size: 3em;"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme</h1>
			</section>
			
		</div>
	<div class="handle fonts">Menu<span class="icon icon-align-justify pull-right"></span>
</div>
<nav id="nal-ul">
	<ul id="nav" class="fonts">
	<?php if(!isset($_SESSION['is_logged_in'])){?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Login</li></a>
	<?php }else{?>
		<a href="<?php echo site_url()?>better/logout"><li class="pull-right">Logout</li></a>
	<?php }?>
		<a href="<?php echo site_url()?>better/contact_page"><li class="pull-right active-link">Contact</li></a>
		<a href="<?php echo site_url()?>better/gallery_page"><li class="pull-right ">Gallery</li></a>
		<a href="<?php echo site_url()?>better/admissions_page"><li class="pull-right ">Admissions</li></a>
		<a href="<?php echo site_url()?>better/about_page"><li class="pull-right ">About</li></a>
		<a href="<?php echo site_url()?>"><li class="pull-right">Home</li></a>

		
	</ul>
</nav>
</header>


<section>
	<div class="row subs-form suby">
		<div class="col-lg-6 mailer">
			<h1>Send us a Message</h1>
			<p>Please Use the form below to reach us. Someone will reach back to you.</p>
			<label id="name-mail"></label>
			<input type="text" id="form-input" name="" placeholder="Your Name" onfocus="setLabel()">
			<label id="email-mail"></label>
			<input type="text" id="form-input" name="" placeholder="Your Email" onfocus="setLabel()">
			<label id="msg-mail"></label>
			<textarea placeholder="Your Message" style="height: 200px; width: 100%;"></textarea><br>
			<button class="btn-subscribe">Send</button>
		</div>
		<div class="col-lg-6">
			<h1>Subscribe to our Newsletter</h1>
			<p>Please subscribe to our weekly newsletter for updates on our products, events etc.</p>
			<label id="name-sub"></label>
			<input type="text" id="form-input" name="" placeholder="Your Name" onfocus="setLabel()">
			<label id="email-sub"></label>
			<input type="text" id="form-input" name="" placeholder="Your Email" onfocus="setLabel()">
			<button class="btn-subscribe">Subscribe</button>
		</div>
	</div>
</section>