
<header>
		<div id="top-info">
			<section>
				<h1 style="font-size: 5em;" id="name" class="fonts"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme Educational Consultants</h1><h1 id="name2" class="fonts" style="font-size: 3em;"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme</h1>
			</section>
			
		</div>
	<div class="handle fonts">Menu<span class="icon icon-align-justify pull-right"></span>
</div>
<nav id="nal-ul">
	<ul id="nav" class="fonts">
	<?php if(!isset($_SESSION['is_logged_in'])){?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Login</li></a>
	<?php }else{?>
		<a href="<?php echo site_url()?>better/logout"><li class="pull-right">Logout</li></a>
	<?php }?>
		<a href="<?php echo site_url()?>better/contact_page"><li class="pull-right">Contact</li></a>
		<a href="<?php echo site_url()?>better/gallery_page"><li class="pull-right active-link">Gallery</li></a>
		<a href="<?php echo site_url()?>better/admissions_page"><li class="pull-right ">Admissions</li></a>
		<a href="<?php echo site_url()?>better/about_page"><li class="pull-right ">About</li></a>
		<a href="<?php echo site_url()?>"><li class="pull-right">Home</li></a>

		
	</ul>
</nav>
</header>


<section>
	<div  class="row">
		<div class="col-lg-6">
			<div class="img">
				<a target="_blank" href="<?php echo base_url()?>images/students.jpg">
				    <img src="<?php echo site_url()?>images/students.jpg" alt="Betterme Schools">
				</a>
				<div class="desc">Students in our schools during chow time</div>
			</div>
		</div>
		<div class="col-lg-6">
			<div class="img">
				<a target="_blank" href="<?php echo base_url()?>images/klematis_big.htm">
				    <img src="<?php echo site_url()?>images/students.jpg" alt="Betterme Schools">
				</a>
				<div class="desc">Students in our schools during chow time</div>
			</div>
		</div>
	</div>
	<div  class="row">
		<div class="col-lg-6">
			<div class="img">
				<a target="_blank" href="<?php echo base_url()?>images/klematis_big.htm">
				    <img src="<?php echo site_url()?>images/students.jpg" alt="Betterme Schools">
				</a>
				<div class="desc">Students in our schools during chow time</div>
			</div>
		</div>
		<div class="col-lg-6">
			<div class="img">
				<a target="_blank" href="<?php echo base_url()?>images/klematis_big.htm">
				    <img src="<?php echo site_url()?>images/students.jpg" alt="Betterme Schools">
				</a>
				<div class="desc">Students in our schools during chow time</div>
			</div>
		</div>
	</div>
</section>