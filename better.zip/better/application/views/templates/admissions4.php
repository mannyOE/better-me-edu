
<header>
		<div id="top-info">
			<section>
				<h1 style="font-size: 3em;" id="name" class="fonts"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme Consultants</h1><h1 id="name2" class="fonts" style="font-size: 3em;"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme</h1>
			</section>
			
		</div>
	<div class="handle fonts">Menu<span class="icon icon-align-justify pull-right"></span>
</div>
<nav id="nal-ul">
	<ul id="nav" class="fonts">
	<?php if(!isset($_SESSION['is_logged_in'])){?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Login</li></a>
	<?php }else{?>
		<a href="<?php echo site_url()?>better/logout"><li class="pull-right">Logout</li></a>
	<?php }?>
		<a href="<?php echo site_url()?>better/contact_page"><li class="pull-right">Contact</li></a>
		<a href="<?php echo site_url()?>better/gallery_page"><li class="pull-right">Gallery</li></a>
		<a href="<?php echo site_url()?>better/admissions_page"><li class="pull-right active-link">Admissions</li></a>
		<a href="<?php echo site_url()?>better/about_page"><li class="pull-right ">About</li></a>
		<a href="<?php echo site_url()?>"><li class="pull-right">Home</li></a>

		
	</ul>
</nav>
</header>

<section>
<form>
<div style="text-align: center;" ><h1>Other Information</h1>
<span><strong>(NOTE: ALL FIELDS ARE REQUIRED. FAILURE TO COMPLY MAY LEAD TO DISQUALIFICATION)</strong></span></div>
	<div class="row suby">
		<div class="col-lg-2">

		</div>
		<div class="col-lg-4">
		<form action="<?php echo site_url()?>better/">
			<fieldset>
				<legend>Choose Subjects</legend>
				<input type="checkbox" id="subjects" autofocus="true" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Bike"> English
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Basic Science
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Mathematics
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Physics
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Chemistry 
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Basic Technology
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Biology
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Computer Training
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Further Mathematics
				<br>
				<input type="checkbox" id="subjects" style="font-size: 22px; height: 30px; width: 30px;" name="subjects[]" value="Car"> Data Processing 
			</fieldset>
			<fieldset>
				<legend>Pick a Suitable Schedule</legend>
				<input type="radio" style="font-size: 22px; height: 30px; width: 30px;" name="schedule" value="male"> Evening Session
				<br>
				<input type="radio" style="font-size: 22px; height: 30px; width: 30px;" name="schedule" value="female"> Morning Session
			</fieldset>
			<fieldset>
			<legend>Programme Duration.</legend>
				<input type="radio" style="font-size: 22px; height: 30px; width: 30px;" name="duration" value="male"> 6 Months
				<br>
				<input type="radio" style="font-size: 22px; height: 30px; width: 30px;" name="duration" value="female"> 12 Months<br>
				<input type="radio" style="font-size: 22px; height: 30px; width: 30px;" name="duration" value="male"> 18 Months
				<br>
				<input type="radio" style="font-size: 22px; height: 30px; width: 30px;" name="duration" value="female"> 24 Months
			</fieldset>
		</div>
		<div class="col-lg-4">
			<fieldset><legend>Referee Information</legend>

			<label id="fn-adm">Referee Name</label>
			<input id="this-form" type="text" name="ref_name" value="<?php echo set_value('ref_name'); ?>" placeholder="" >
			<span id="error-form"><?php echo form_error('ref_name'); ?></span>

			<label id="fn-adm">Referee Phone</label>
			<input id="this-form" type="text" name="ref_phone" value="<?php echo set_value('ref_phone'); ?>" placeholder="" >
			<span id="error-form"><?php echo form_error('ref_phone'); ?></span>
			</fieldset>
			<input type="checkbox" style="font-size: 22px; height: 30px; width: 30px;" name="subjects" value="Car"> I Accept the <a href="">Terms and Conditions</a>
				<br>
			<button class="btn-subscribe pull-right stage-4-btn">Save and Continue</button>
		</div></form>
		<div class="col-lg-2 suby subs-form category">
		<a href="<?php echo site_url();?>better/reg_5_state">Click here</a>

		</div>

	</div>
</form>
</section>





<script type="text/javascript">
function gah(){
	document.getElementById("subjects").val
}
</script>
<style type="text/css">
	label{
		font-size: 22px;
		font-family: Ubuntu;
		font-weight: bold;
	}
</style>