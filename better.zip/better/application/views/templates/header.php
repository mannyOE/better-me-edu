<!DOCTYPE html>
<html>
<head>
	<title>Betterme || Educational Consultants</title>
	<link rel="stylesheet" type="text/css" href="<?php echo site_url()?>css/dropzone.css">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url()?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url()?>css/blueberry.css">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url()?>css/dropzone.css">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url()?>css/bootstrap-responsive.css">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url()?>bootstrap/bootstrap.min.css">
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width initial-scale=1.0"/>

</head>
<body>


