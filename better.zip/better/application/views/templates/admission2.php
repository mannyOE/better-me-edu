
<header>
		<div id="top-info">
			<section>
				<h1 style="font-size: 3em;" id="name" class="fonts"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme Consultants</h1><h1 id="name2" class="fonts" style="font-size: 3em;"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme</h1>
			</section>
			
		</div>
	<div class="handle fonts">Menu<span class="icon icon-align-justify pull-right"></span>
</div>
<nav id="nal-ul">
	<ul id="nav" class="fonts">
	<?php if(!$_SESSION['is_logged_in']=='yes'){?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Login</li></a>
	<?php }else{?>
		<a href="<?php echo site_url()?>better/logout"><li class="pull-right">Logout</li></a>
	<?php }?>
		<a href="<?php echo site_url()?>better/contact_page"><li class="pull-right">Contact</li></a>
		<a href="<?php echo site_url()?>better/gallery_page"><li class="pull-right">Gallery</li></a>
		<a href="<?php echo site_url()?>better/admissions_page"><li class="pull-right active-link">Admissions</li></a>
		<a href="<?php echo site_url()?>better/about_page"><li class="pull-right ">About</li></a>
		<a href="<?php echo site_url()?>"><li class="pull-right">Home</li></a>

		
	</ul>
</nav>
</header>

<section>
<form action="<?php echo site_url()?>better/reg_2_pager" method="post">
	<div class="row suby">
		<div class="col-lg-2">
			
		</div>
		<div class="col-lg-4 ">
			<h1>Personal Details</h1>
			<label>Home Address</label>
			<input type="text" id="this-form" name="haddr" autofocus="true" value="<?php echo set_value('haddr'); ?>">
			<span id="error-form"><?php echo form_error('haddr'); ?></span>

			<label>Mother's Maiden Name</label>
			<input type="text" id="this-form" name="mother" value="<?php echo set_value('mother'); ?>">
			<span id="error-form"><?php echo form_error('mother'); ?></span>

			<label>Last School</label>
			<input type="text" id="this-form" name="lsch" value="<?php echo set_value('lsch'); ?>">
			<span id="error-form"><?php echo form_error('lsch'); ?></span>

			<label>Last Result</label>
			<input type="text" id="this-form" name="lsres" value="<?php echo set_value('lsres'); ?>">
			<span id="error-form"><?php echo form_error('lsres'); ?></span>

			<label>Skills</label>
			<input type="text" id="this-form" name="skil" value="<?php echo set_value('skil'); ?>">
			<span id="error-form"><?php echo form_error('skil'); ?></span>


		</div>
		<div class="col-lg-4  ">
			<h2 style="color: white" id="cat2">Catgory</h2>

			<label>Gender</label>
			<input type="text" id="this-form" name="sex" value="<?php echo set_value('sex'); ?>">
			<span id="error-form"><?php echo form_error('sex'); ?></span>

			<label>Date of Birth</label>
			<input type="text" id="this-form" name="dob" value="<?php echo set_value('dob'); ?>">
			<span id="error-form"><?php echo form_error('dob'); ?></span>

			<label>Place of Birth</label>
			<input type="text" id="this-form" name="pob" value="<?php echo set_value('pob'); ?>">
			<span id="error-form"><?php echo form_error('pob'); ?></span>

			<label>Disabilities</label>
			<input type="text" id="this-form" name="dable" value="<?php echo set_value('dable'); ?>">
			<span id="error-form"><?php echo form_error('dable'); ?></span>

			<label>Religion</label>
			<input type="text" id="this-form" name="relig" value="<?php echo set_value('relig'); ?>">
			<span id="error-form"><?php echo form_error('relig'); ?></span>

			<button class="btn-subscribe pull-right">Save and Continue</button>
		</div>
		<div class="col-lg-2">
			
		</div>
	</div>
	</form>
</section>





<script type="text/javascript">

</script>
<style type="text/css">
	label{
		font-size: 22px;
		font-family: Ubuntu;
		font-weight: bold;
	}
</style>