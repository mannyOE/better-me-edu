
<header>
		<div id="top-info">
			<section>
				<h1 style="font-size: 5em;" id="name" class="fonts"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme Educational Consultants</h1><h1 id="name2" class="fonts" style="font-size: 3em;"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme</h1>
			</section>
			
		</div>
	<div class="handle fonts">Menu<span class="icon icon-align-justify pull-right"></span>
</div>
<nav id="nal-ul">
	<ul id="nav" class="fonts">
	<?php if(!isset($_SESSION['is_logged_in'])){?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Login</li></a>
	<?php }else{?>
		<a href="<?php echo site_url()?>better/logout"><li class="pull-right">Logout</li></a>
	<?php }?>
		<a href="<?php echo site_url()?>better/contact_page"><li class="pull-right">Contact</li></a>
		<a href="<?php echo site_url()?>better/gallery_page"><li class="pull-right">Gallery</li></a>
		<a href="<?php echo site_url()?>better/admissions_page"><li class="pull-right">Admissions</li></a>
		<a href="<?php echo site_url()?>better/about_page"><li class="pull-right active-link">About</li></a>
		<a href="<?php echo site_url()?>"><li class="pull-right">Home</li></a>

		
	</ul>
</nav>
</header>


<div class="container-fluid fonts body-content">
	<div class="row">
		<div class="col-lg-4">
			<section id="img-info">
				<div id="img-top"><img src="<?php echo site_url()?>images/rea-passion.jpg" class="img-circle circler"></div>
				<div id="img-info" class="fonts2">
				<h2>Our Passion</h2>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
			</section>
		</div>
		<div class="col-lg-4">
			<section id="img-info">
				<div id="img-top"><img src="<?php echo site_url()?>images/teacher.jpg" class="img-circle circler"></div>
				<div id="img-info" class="fonts2">
				<h2>Our Teachers</h2>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
			</section>
		</div>
		<div class="col-lg-4">
			<section id="img-info">
				<div id="img-top"><img src="<?php echo site_url()?>images/Library.JPG" class="img-circle circler"></div>
				<div id="img-info" class="fonts2">
				<h2>Our Facilities</h2>
				<span id="img-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></div>
			</section>
		</div>
	</div>
	<div class="row new-row">
		<div class="col-lg-6">
			<img src="<?php echo site_url()?>images/students.jpg">
		</div>
		<div class="col-lg-6" id="img-info">
		<h2>The Management</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			<span id="demo"></span>
		</div>
	</div>

	<div class="row new-row">
		<div class="col-lg-6" id="img-info">
		<h2>The Management</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			<span id="demo"></span>
		</div>
		<div class="col-lg-6">
			<img src="<?php echo site_url()?>images/students.jpg">
		</div>
	</div>

	<div class="row new-row">
		<div class="col-lg-6">
			<img src="<?php echo site_url()?>images/students.jpg">
		</div>
		<div class="col-lg-6" id="img-info">
		<h2>The Management</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			<span id="demo"></span>
		</div>
	</div>
</div>




