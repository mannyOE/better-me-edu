
<header>
		<div id="top-info">
			<section>
				<h1 style="font-size: 5em;" id="name" class="fonts"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme Educational Consultants</h1><h1 id="name2" class="fonts" style="font-size: 3em;"><img src="<?php echo site_url()?>images/new_logo.jpg">Betterme</h1>
			</section>
		</div>
	<div class="handle fonts">Menu<span class="icon icon-align-justify pull-right"></span>
</div>
<nav id="nal-ul">
	<ul id="nav" class="fonts">
	<?php if(!isset($_SESSION['is_logged_in'])){?>
		<a href="<?php echo site_url()?>better/login_page"><li class="pull-right">Login</li></a>
	<?php }else{?>
		<a href="<?php echo site_url()?>better/logout"><li class="pull-right">Logout</li></a>
	<?php }?>
		<a href="<?php echo site_url()?>better/contact_page"><li class="pull-right">Contact</li></a>
		<a href="<?php echo site_url()?>better/gallery_page"><li class="pull-right">Gallery</li></a>
		<a href="<?php echo site_url()?>better/admissions_page"><li class="pull-right">Admissions</li></a>
		<a href="<?php echo site_url()?>better/about_page"><li class="pull-right ">About</li></a>
		<a href="<?php echo site_url()?>"><li class="pull-right active-link">Home</li></a>

		
	</ul>
</nav>
</header>


<div class="container-fluid">
	<div class="blueberry" style="max-width: 600px;">
		<ul class="slides">
			<a href="<?php echo site_url()?>"><li><img src="<?php echo site_url()?>images/students.jpg"><div class="carousel-caption" style="padding-bottom: 50px;">Happy Children</div></li></a>
			<a href="<?php echo site_url()?>"><li><img src="<?php echo site_url()?>images/kids.jpg"><div class="carousel-caption" style="padding-bottom: 50px;">Happy Children</div></li></a>
			<a href="<?php echo site_url()?>"><li><img src="<?php echo site_url()?>images/hjids.jpg"><div class="carousel-caption" style="padding-bottom: 50px;">Happy Children</div></li></a>
		</ul>
	</div>
</div>






