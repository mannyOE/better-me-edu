
<footer >
	<div class="top-footer"><span class="copyright">&copy 2017 <a href="http://customprojectsbynuel.comeze.com" style="text-decoration: none;">Customprojects.com</a></span></div>
	<section>
		<div class="row">
			<div class="col-lg-6 foot-font">
				<h4>Schools and Colleges</h4>
					<p>
						Design and Execute Blended-Learning Program
					</p>
					<p>
						Develop Methods to optimize student learning environment
					</p>
					</p>
						Build online education options and after-school enrichment services
					</p>
					<p>
						Establish School-business network and recruitment of quality teachers
					</p>
			</div>
			<div class="col-lg-6 foot-font">
				<h4>Individual Students and Their Family</h4>
				<p>
						Optimize student academic potential
					</p>
					<p>
						Discover and develop new talent in student
					</p>
					<p>
						Analyze the individual learning need of the studentt
					</p>
					<p>
						Arrange specialty testing and evaluation for the student when needed
					</p>
			</div>
		</div>
	</section>
	<div class="top-footer"></div>
</footer>
	<script type="text/javascript" src="<?php echo site_url()?>js/jquery-1.9.1.min.js" ></script>
	<script type="text/javascript" src="<?php echo site_url()?>js/jquery.blueberry.js" ></script>
	<script type="text/javascript" src="<?php echo site_url()?>js/bootstrap.min.js" ></script>
	<script type="text/javascript" src="<?php echo site_url()?>scripts/thisandthat.js" ></script>
	<script type="text/javascript" src="<?php echo site_url()?>js/dropzone.js"></script>