<?php /**
* the betterme model starts here
*/
class Betterme extends CI_Model
{
	
	function loging_in($uname,$pwd){
		$this->db->select('*')->from('students')->where('username',$uname)->where('password',$pwd);
		if($this->db->get()->num_rows()>0){
			return true;
		}else{
			return false;
		}
	}

	function reg_2_model($reg_2_input){
		$this->db->where('username',$_SESSION['uname'])->update('students',$reg_2_input);
	}


	function signing_up($username,$signup_input){
		$this->db->select('*')->where('username',$username);
		if(!$this->db->get('students')->num_rows()>0){
			$this->db->insert('students',$signup_input);
		}
	}
	function fake_email($username){
		$this->db->where('username',$username)->delete('students');
	}

	function confirm_email($username){
		$this->db->where('username',$username)->set('email_confirmed',"1")->update('students');
	}

	function getRegState($uname){
		$dbql=$this->db->select('registration_comp')->where('username',$uname)->get('students')->result();
		foreach ($dbql as $key) {
			# code...
			$state = $key->registration_comp;
		}
		$_SESSION['state']=$state;
		return $state;
	}

	









	
} ?>