<?php /**
* 
*/
class JobsModel extends CI_Model
{
	
	function __construct()
	{
		# code...
	}
	
} ?>