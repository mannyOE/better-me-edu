<?php /**
* 
*/
class Better extends CI_Controller
{
	function index(){
		$this->load->view('templates/header');
		$this->load->view('templates/banner');
		$this->load->view('templates/footer');
	}
	function about_page(){
		$this->load->view('templates/header');
		$this->load->view('templates/about');
		$this->load->view('templates/footer');

	}
	function admissions_page(){
		if($_GET){
			$data['msg']=$this->input->get('message');
		}else{
			$data['msg'] = "";
		}
		if (isset($_SESSION['state'])) {
			# code...
			$state = $_SESSION['state'];
			$this->switcher($state);
		}else{
			$this->load->view('templates/header');
			$this->load->view('templates/admissions',$data);
			$this->load->view('templates/footer');
		}
	}
	function gallery_page(){
		$this->load->view('templates/header');
		$this->load->view('templates/gallery');
		$this->load->view('templates/footer');

	}
	function contact_page(){
		$this->load->view('templates/header');
		$this->load->view('templates/contact');
		$this->load->view('templates/footer');

	}
	function login_page(){
		if($_GET){
			$data['heading']="You May Login Now.";
		}else{
			$data['heading']="Login Here";
		}
		$this->load->view('templates/header');
		$this->load->view('templates/login',$data);
		$this->load->view('templates/footer');
		
	}
	function FradPOSKBDVECWHVCGVTYFWYUHIUhduewfgeywuuqiefgeyw(){
		$username = $_GET['username'];
		$this->betterme->confirm_email($username);
		redirect('better/login_page?status=1');



		//http://localhost/better/better/FradPOSKBDVECWHVCGVTYFWYUHIUhduewfgeywuuqiefgeyw?username=ahmanemmanuel
		
	}

	function login(){
		//set form validation rules
		$this->form_validation->set_rules('username_login','','required');
		$this->form_validation->set_rules('password_login','','required');

		//check if validation is ok
		if($this->form_validation->run()==true){
			$uname=$this->input->post('username_login');
			$pwd=$this->input->post('password_login');
			$stat=$this->betterme->loging_in($uname,$pwd);
			if($stat==true){
				$_SESSION['is_logged_in']='yes';
				$_SESSION['uname']=$uname;
				$this->switcher($state);
			}else{
				$_SESSION['error']='h';
				$this->login_page();
			}
		}else{
			redirect('better/login_page');
		}
	}

	function switcher(){
		$state = $this->betterme->getRegstate($_SESSION['uname']);
		switch ($state) {
					case '1':
						# code...
						redirect("better/reg_2_state");
						break;
					
					case '2':
						# code...
						redirect("better/reg_3_state");
						break;
					
					case '3':
						# code...
						redirect("better/reg_4_state");
						break;
					case '4':
						# code...
						redirect("better/reg_5_state");
						break;

					default:
						# code...
						break;
				}
	}
	function signup(){
		//setting validation rules here 
		$this->form_validation->set_rules('fname','First Name','required');
		$this->form_validation->set_rules('mname','Middle Name','required');
		$this->form_validation->set_rules('lname','Last Name','required');
		$this->form_validation->set_rules('username','Username','required|is_unique[students.username]');
		$this->form_validation->set_rules('phone','Phone','required');
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('confirmPassword','Password Confirm','required|matches[password]');

		//checking for rule adherence
		if($this->form_validation->run()==TRUE){
			$fname = $this->input->post('fname');
			$mname = $this->input->post('mname');
			$lname = $this->input->post('lname');
			$email = $this->input->post('email');
			$phone = $this->input->post('phone');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$signup_input = array('registration_comp'=> "1",'fname' => $fname, 'mname'=>$mname, 'lname'=>$lname, 'email'=>$email, 'phone'=>$phone, 'username'=>$username, 'password'=>$password );
			// call to the model method for database query to insert the array $signup_input
			$this->betterme->signing_up($username,$signup_input);
			// $name = $fname." ".$mname." ".$lname;
			// $content = "<h2>Thank You for Regiistering with us</h2><p>To confirm your email address and continue with registration, please click on the link below and if it is not clickable, copy it and paste in your browser address bar. Do not reply this email.</p><p>http://localhost/better/better/FradPOSKBDVECWHVCGVTYFWYUHIUhduewfgeywuuqiefgeyw?username=".$username."</p>";
			// $subject = "Betterme: Confirmation Email";
			// $recipient = $email;
			// $sender = "bettermeconsulting@gmail.com";

			// $mailheader = "From: $sender\\r\\n";
			// $mailheader .= "MIME-Version: 1.0\\r\\n";


			// $success = mail($recipient, $subject, $content, $mailheader);
			// if($success == true){
			// 	$_SESSION['go_and_confirm_email']='yes';
			// 	redirect('better/admissions_page_after_one');
			// }else{
			// 	$this->betterme->fake_email($username);
			// 	redirect("better/admissions_page?message=Invalid email. Please try again.");
				
			// }
			redirect("better/FradPOSKBDVECWHVCGVTYFWYUHIUhduewfgeywuuqiefgeyw?username=".$username);

		}else{
			$this->admissions_page();
		}


	}





	function admissions_page_after_one(){
		$this->load->view('templates/header');
		$this->load->view('templates/admissions_after');
		$this->load->view('templates/footer');
	}

	function reg_2_state()
	{
		# code...
		$this->load->view('templates/header');
		$this->load->view('templates/admission2');
		$this->load->view('templates/footer');

	}

	function reg_3_state()
	{
		# code...
		$this->load->view('templates/header');
		$this->load->view('templates/admissions3');
		$this->load->view('templates/footer');

	}
	function reg_4_state()
	{
		# code...
		$this->load->view('templates/header');
		$this->load->view('templates/admissions4');
		$this->load->view('templates/footer');

	}
	function reg_5_state()
	{
		# code...
		$this->load->view('templates/header');
		$this->load->view('templates/admission_photo');
		$this->load->view('templates/footer');

	}

	function reg_2_pager(){
		$this->form_validation->set_rules('haddr','Home Address','required');
		$this->form_validation->set_rules('mother','Mothers Maiden Name','required');
		$this->form_validation->set_rules('dob','Date of Birth','required');
		$this->form_validation->set_rules('pob','Place of Birth','required');
		$this->form_validation->set_rules('sex','Gender','required');
		$this->form_validation->set_rules('skil','Skill','required');
		$this->form_validation->set_rules('lsres','Last Result','required');
		$this->form_validation->set_rules('lsch','Last School','required');
		$this->form_validation->set_rules('relig','Religion','required');
		$this->form_validation->set_rules('dable','Disabilities','required');

		if($this->form_validation->run()==true){
			$haddr=$this->input->post('haddr');
			$mother=$this->input->post('mother');
			$lsch=$this->input->post('lsch');
			$lsres=$this->input->post('lsres');
			$skil=$this->input->post('skil');
			$relig=$this->input->post('relig');
			$sex=$this->input->post('sex');
			$dob=$this->input->post('dob');
			$pob=$this->input->post('pob');
			$dable=$this->input->post('dable');
			$reg_2_input = array('haddr' =>$haddr ,'mother' =>$mother ,'lsch' =>$lsch ,'lsres' =>$lsres ,'skil' =>$skil ,'relig' =>$relig ,'sex' =>$sex ,'dob' =>$dob ,'pob' =>$pob ,'dable' =>$dable,'registration_comp'=>'2' );

			$this->betterme->reg_2_model($reg_2_input);
			$this->switcher();


		}else{
			$this->reg_2_state();
		}
	}


	function reg_3_pager(){
		$this->form_validation->set_rules('haddr','Father Qualification','required');
		$this->form_validation->set_rules('mother','Fathers Post Held','required');
		$this->form_validation->set_rules('dob','Fathers Contact Number','required');
		$this->form_validation->set_rules('pob','Mothers Occupation','required');
		$this->form_validation->set_rules('sex','Fathers Occupation','required');
		$this->form_validation->set_rules('lsres','Mothers Post','required');
		$this->form_validation->set_rules('lsch','Mothers Qualification','required');
		$this->form_validation->set_rules('dable','Mothers Contact Number','required');

		if($this->form_validation->run()==true){
			$haddr=$this->input->post('haddr');
			$mother=$this->input->post('mother');
			$lsch=$this->input->post('lsch');
			$lsres=$this->input->post('lsres');
			$sex=$this->input->post('sex');
			$dob=$this->input->post('dob');
			$pob=$this->input->post('pob');
			$dable=$this->input->post('dable');
			$reg_2_input = array('fqual' =>$haddr ,'fpost' =>$mother ,'moqual' =>$lsch ,'mopost' =>$lsres ,'foccu' =>$sex ,'fcon' =>$dob ,'moccu' =>$pob ,'mcon' =>$dable,'registration_comp'=>'3' );

			$this->betterme->reg_2_model($reg_2_input);
			$this->switcher();


		}else{
			$this->reg_2_state();
		}
	}

// 	haddr
// mother
// lsch
// lsres
// skil
// relig
// sex
// dob
// pob
// dable

	function reg_4_pager(){
		$this->form_validation->set_rules('haddr','Father Qualification','required');
		$this->form_validation->set_rules('mother','Fathers Post Held','required');
		$this->form_validation->set_rules('dob','Fathers Contact Number','required');
		$this->form_validation->set_rules('pob','Mothers Occupation','required');
		$this->form_validation->set_rules('sex','Fathers Occupation','required');
		$this->form_validation->set_rules('lsres','Mothers Post','required');
		$this->form_validation->set_rules('lsch','Mothers Qualification','required');
		$this->form_validation->set_rules('dable','Mothers Contact Number','required');

		if($this->form_validation->run()==true){
			$haddr=$this->input->post('haddr');
			$mother=$this->input->post('mother');
			$lsch=$this->input->post('lsch');
			$lsres=$this->input->post('lsres');
			$sex=$this->input->post('sex');
			$dob=$this->input->post('dob');
			$pob=$this->input->post('pob');
			$dable=$this->input->post('dable');
			$reg_2_input = array('fqual' =>$haddr ,'fpost' =>$mother ,'moqual' =>$lsch ,'mopost' =>$lsres ,'foccu' =>$sex ,'fcon' =>$dob ,'moccu' =>$pob ,'mcon' =>$dable,'registration_comp'=>'3' );

			$this->betterme->reg_2_model($reg_2_input);
			$this->switcher();


		}else{
			$this->reg_2_state();
		}
	}

	function logout(){
		unset($_SESSION['is_logged_in']);
		unset($_SESSION['state']);
		redirect("better");
	}






} ?>